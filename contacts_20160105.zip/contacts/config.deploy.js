var config = {
	virtualDir: '/node/contacts/server.js'
}

module.exports = config;