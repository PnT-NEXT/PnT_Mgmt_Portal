var trainings	= require('./trainings'),
	users		= require('./users');

module.exports = {
	trainings: 	trainings,
	users: 		users
};