var config = {
	virtualDir: '',
	authUser: 'xiaofan',
	userRegion: 'ASIAPACIFIC',
	userName: 'Xiao.Fang',
	email: 'fxiao@hpe.com'
}

module.exports = config;